/**************DO NOT MODIFY THIS LINE BELOW*****************/
const climateData = require('../climate-data')


/*
Write your question, and any planning notes in this comment block:

Question:


Notes:


*/

// Your code here


/* When you are ready to run your function, call it inside the console.log()
below.

Run your code using the command `node problems/05-choose-your-own-adventure.js`
*/
console.log();